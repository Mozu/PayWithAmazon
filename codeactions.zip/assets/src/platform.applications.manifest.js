module.exports = {
  
  'embedded.platform.applications.install': {
      actionName:'embedded.platform.applications.install',
      customFunction: require('./domains/platform.applications/embedded.platform.applications.install')
   }
  
};