module.exports = {
  
  'http.commerce.orders.setFulFillmentInfo.before': {
      actionName:'http.commerce.orders.setFulFillmentInfo.before',
      customFunction: require('./domains/commerce.orders/http.commerce.orders.setFulFillmentInfo.before')
   },
  
  'http.commerce.orders.setBillingInfo.before': {
      actionName:'http.commerce.orders.setBillingInfo.before',
      customFunction: require('./domains/commerce.orders/http.commerce.orders.setBillingInfo.before')
   }
  
};