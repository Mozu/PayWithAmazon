module.exports = {
	PAYMENTSETTINGID : "PayByAmazon",
	ENVIRONMENT: "environment",
	SELLERID: "sellerId",
	CLIENTID: "clientId",
	APPID: "appId",
	AWSACCESSKEYID: "awsAccessKeyId",
	AWSSECRET: "awsSecret",
	REGION: "region",
	ORDERPROCESSING: "orderProcessing",
	ACCESSTOKEN: "access_token"
};