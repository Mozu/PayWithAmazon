var url = require("url");
var qs = require("querystring");
var _ = require("underscore");
var xmlDoc = require("xmldoc");
var amazonPay = require("./amazonpaysdk")();
var constants = require("mozu-node-sdk/constants");
var paymentConstants = require("./constants");
var orderClient = require("mozu-node-sdk/clients/commerce/order")();
var fulfillmentInfoClient = require('mozu-node-sdk/clients/commerce/orders/fulfillmentInfo')();
var paymentSettingsClient = require("mozu-node-sdk/clients/commerce/settings/checkout/paymentSettings")();
paymentSettingsClient.context[constants.headers.USERCLAIMS] = null;


function createOrderFromCart(cartId) {
  return orderClient.createOrderFromCart({ cartId: ''+cartId+''  }).then(function(order) {
    console.log("Order fulfillmentInfo" ,order.fulfillmentInfo);

    if (!order.fulfillmentInfo && !order.fulfillmentInfo.data && !order.fulfillmentInfo.data.awsReferenceId) return order;

    //already associated with an aws order...validate that it is not cancelled
    return amazonPay.getOrderDetails(order.fulfillmentInfo.data.awsReferenceId).then(function(awsOrder) {
        var doc = new xmlDoc.XmlDocument(awsOrder);
        var state = doc.valueWithPath("GetOrderReferenceDetailsResult.OrderReferenceDetails.OrderReferenceStatus.State");
        console.log("Aws Order status", state);
        if (state == "Canceled") {
          order.fulfillmentinfo = null;
          return orderClient.updateOrder({id: order.id},order);
        } else {
           console.log("AWS order is not canceled, returning order");
           return order;
        }
    });
  });      
}


function configure(continueIfDisabled, nameSpace, cb) {
   var promise = new Promise(function(resolve,reject) {
      paymentSettingsClient.getThirdPartyPaymentWorkflowWithValues({name: nameSpace+"~"+paymentConstants.PAYMENTSETTINGID})
      .then(function(paymentSetting) {
        console.log(paymentSetting);
        if (!continueIfDisabled && !paymentSetting.isEnabled) cb();

        var environment = getValue(paymentSetting, paymentConstants.ENVIRONMENT);
        var isSandbox = environment == "sandbox";
        var region = getValue(paymentSetting, paymentConstants.REGION);
        var awsSecret = getValue(paymentSetting, paymentConstants.AWSSECRET);
        var awsAccessKeyId = getValue(paymentSetting, paymentConstants.AWSACCESSKEYID);
        var sellerId = getValue(paymentSetting, paymentConstants.SELLERID);
        var appId = getValue(paymentSetting, paymentConstants.APPID);

        var config = {"isSandbox" : isSandbox, 
                      "awsAccessKeyId" : awsAccessKeyId, 
                          "awsSecret" : awsSecret,
                          "sellerId" : sellerId,
                          "region" : region,
                          "app_id" : appId};


        console.log("Amazon pay config", config);
        amazonPay.configure(config);
        resolve(paymentSetting.isEnabled);
      }, function(err) {
        reject(err);
      });
  });

  return promise;
}


function getFulfillmentInfo(awsOrder, data) {
  var doc = new xmlDoc.XmlDocument(awsOrder);

  console.log(doc.valueWithPath("GetOrderReferenceDetailsResult.OrderReferenceDetails.OrderReferenceStatus.State"));
  
  var destinationPath = "GetOrderReferenceDetailsResult.OrderReferenceDetails.Destination.PhysicalDestination";

  var name = doc.valueWithPath(destinationPath+".Name"); 
  return { "fulfillmentContact" : { 
            "firstName" : name.split(" ")[0], 
            "lastNameOrSurname" : name.split(" ")[1], 
            "phoneNumbers" : {
              "home" : doc.valueWithPath(destinationPath+".Phone")
            },
            "address" : {
              "address1" : doc.valueWithPath(destinationPath+".AddressLine1"),
              "address2" : doc.valueWithPath(destinationPath+".AddressLine2"),
              "cityOrTown" : doc.valueWithPath(destinationPath+".City"),
              "stateOrProvince": doc.valueWithPath(destinationPath+".StateOrRegion"),
              "postalOrZipCode": doc.valueWithPath(destinationPath+".PostalCode"),
              "countryCode": doc.valueWithPath(destinationPath+".CountryCode"),
              "addressType": "Residential",
              "isValidated": "true"
            }
          },
          "data" : data
    };
}

function parseUrlParams() {
  var urlParseResult = url.parse(self.ctx.request.url);
  console.log("parsedUrl", urlParseResult);
  queryStringParams = qs.parse(urlParseResult.query);
  return queryStringParams;
}

function isAmazonCheckout(params) {
  var hasAmzParams = _.has(params, 'access_token') && _.has(params, "isAwsCheckout");
  console.log("is Amazon checkout?", hasAmzParams);
  return hasAmzParams;
}


function getValue(paymentSetting, key) {
  var value = _.findWhere(paymentSetting.credentials, {"apiName" : key});

    if (!value) {
      console.log(key+" not found");
      return;
    }
    //console.log("Key: "+key, value.value );
    return value.value;
}



module.exports = function(context, callback) {
  var self = this;
  self.ctx = context;
  self.cb = callback;
  self.nameSpace = context.apiContext.appKey.split(".")[0];

  self.validateAndProcess = function() {
    try {
      var params = parseUrlParams();

      if (!isAmazonCheckout(params)) return self.cb();
      console.log(self.ctx.apiContext);
     
      configure(false, self.nameSpace, self.cb)
      .then(function(result) { 
        return amazonPay.validateToken(params.access_token); 
      }).then(function(isTokenValid) {
        console.log("Is Amazon token valid", isTokenValid);
        var cartId = params.cartId;
        if (isTokenValid && cartId) {
          console.log("Converting cart to order", cartId);
          return createOrderFromCart(cartId);
        } else if (!isTokenValid) {
          console.log("Amazon token and expried, redirecting to cart");
          self.ctx.response.redirect('/cart');
          self.ctx.response.end();
          self.cb();
        } 
      }).then(function(order) {
        console.log("Order created from cart", order.id);
        self.ctx.response.redirect('/checkout/'+order.id+"?access_token="+params.access_token+"&isAwsCheckout=true");
        self.ctx.response.end();
      })
      .then(self.cb, self.cb);      
    }
    catch (e) {
      self.cb(e);
    }
  };

  self.addViewData = function() {
    var params = parseUrlParams();
    if (!isAmazonCheckout(params)) return self.cb();

    configure(false, self.nameSpace, self.cb)
      .then(function(result) { 
        return amazonPay.validateToken(params.access_token); 
      }).then(function(isTokenValid) {
        if (!isTokenValid) {
          console.log("Amazon token and expried, redirecting to cart");
          self.ctx.response.redirect('/cart');
          self.ctx.response.end();
          self.cb();
        } else
            self.ctx.response.viewData.awsCheckout = true;
      });

  };

  self.addBillingInfo = function() {
    console.log(self.ctx.request.params);
    var req = self.ctx.request;
    var billingInfo = req.params.newBillingInfo;
    if (billingInfo.paymentType !== "DigitalWallet" && billingInfo.paymentWorkflow !== paymentConstants.PAYMENTSETTINGID)
      self.cb();

    configure(false, self.nameSpace, self.cb)
    .then(function(result) {
      return fulfillmentInfoClient.getFulfillmentInfo({orderId: req.orderId});
    })
    .then(function(fulfillmentinfo){
      console.log(fulfillmentinfo);
      self.cb();
    }, self.cb);
  };

  self.addFulfillmentInfo = function() {
    console.log(self.ctx.request.params);

    var fulfillmentInfo = self.ctx.request.params.fulfillmentInfo;
    var data = fulfillmentInfo.data;
    if (!data) return self.cb();

    var awsReferenceId = data.awsReferenceId;
    var addressConsentToken = data.addressAuthorizationToken;

    if (!awsReferenceId && !addressConsentToken) { 
      console.log("not an amazon order...");
      return self.cb(); 
    }
    console.log("Reading payment settings for "+self.nameSpace+"~"+paymentConstants.PAYMENTSETTINGID);

    configure(false, self.nameSpace, self.cb)
    .then(function(result) { 
        return amazonPay.validateToken(addressConsentToken); 
    })
    .then(function(isTokenValid){
        if (isTokenValid) {
          console.log("Pay by Amazon token is valid...setting fulfilmment info");
          return amazonPay.getOrderDetails(awsReferenceId, addressConsentToken);
        } else {
          return self.cb("Amazon session expired. Please re-login from cart page to continue checkout");
        }
    })
    .then(function(awsOrder) {
      console.log("Aws order", awsOrder);
      self.ctx.request.params.fulfillmentInfo = getFulfillmentInfo(awsOrder, data);
      console.log("fulfillmentInfo from AWS", self.ctx.request.params.fulfillmentInfo );
      self.cb();
    }, self.cb);
  };

};
