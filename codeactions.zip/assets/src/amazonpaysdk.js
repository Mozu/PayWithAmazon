var crypto 	= require("crypto");
var moment 	= require("moment");
var _ 		= require("underscore");
var needle 	= require('needle');
var crypto 	= require("crypto");
var moment 	= require("moment");
var xmlDoc = require("xmldoc");

var mwsServiceUrls = { "eu" : "mws-eu.amazonservices.com", "na" : "mws.amazonservices.com", "jp" : "mws.amazonservices.jp"  };
var profileEndpointUrls = { "uk" : "amazon.co.uk", "us" : "amazon.com", "de" : "amazon.de", "jp" : "amazon.co.jp" };
var regionMappings = {"de" : "eu", "uk" : "eu", "us" : "na", "jp" : "jp"};
var version = "2013-01-01";

var getBaseParams = function(action, config) {
	return {
		AWSAccessKeyId : config.awsAccessKeyId,
		Action: action,
		SellerId: config.sellerId,
		SignatureMethod: "HmacSHA256",
		SignatureVersion: "2",
		Version: version
	};
};

var sortParams = function(params) {
	var keys = _.keys(params).sort();

	var sortObj = [];
	_.each(keys, function(key) {  
	    sortObj[key] = params[key];
	});
	return sortObj;
};

var buildParamString = function(params, uriEncodeValues) {
	var keys = _.keys(params).sort();

	var paramStr = "";
	_.each(keys, function(key) {  
		if (paramStr !== "")
			paramStr += "&";
	    paramStr += key+"=";
	    if (uriEncodeValues) 
	    	paramStr += encodeURIComponent(params[key]);
	    else
	    	paramStr += params[key];
	});
	return paramStr;	
};

var executeRequest = function(config, params, server, path, body, awsSecret) {
	//add timestamp
	var utcTime = moment.utc();
	params.Timestamp = utcTime.format('YYYY-MM-DDTHH:mm:ss')+"Z";

	params = sortParams(params);

	//sign the request
	var stringToSign = "POST";
	stringToSign += "\n";
	stringToSign += config.server;
	stringToSign += "\n";
	stringToSign += config.path;
	stringToSign += "\n";
	stringToSign += buildParamString(params, true);
	console.log("AWS Params to Sign", stringToSign);
	var signature = crypto.createHmac("sha256", config.awsSecret).update(stringToSign).digest("base64");
	console.log("Aws Signature",signature);
	params.Signature = encodeURIComponent(signature);
	
	var deferredObject = q.defer();
	needle.post("https://"+config.server+config.path, 
	buildParamString(params, false),
	{json: false, parse: false}, 
	function(err, response, body) {

		if (response.statusCode != 200)
			deferredObject.reject(parseErrorToJson(response.body));
		else {
			deferredObject.resolve(body);
		}
	});
	return deferredObject.promise;
};


var parseErrorToJson = function(errorXml) {
	var doc = new xmlDoc.XmlDocument(errorXml);

	return {
		type: doc.valueWithPath("Error.Type"),
		code: doc.valueWithPath("Error.Code"),
		message: doc.valueWithPath("Error.Message")
	};

};


module.exports = function() {
	var self = this;

	self.configure = function(config) {
		self.config = config;
		self.config.profileEnvt = config.isSandbox ? "api.sandbox" : "api";		
		path = config.isSandbox ? '/OffAmazonPayments_Sandbox' : '/OffAmazonPayments';
		self.config.path = path + "/" + version;
		self.config.server = mwsServiceUrls[regionMappings[config.region]];
	};

	self.validateToken = function(access_token) {
		var deferredObject = q.defer();
		self.getProfile(access_token).then(function(data) {

				var validToken = !(data.error && data.error == "invalid_token") && data.app_id == self.config.app_id;
				deferredObject.resolve(validToken);
			}, function(err) {
				deferredObject.reject(err);
			}
		);
		return deferredObject.promise;
	};

	self.getProfile = function(access_token) {
		access_token = encodeURIComponent(access_token);
		var deferredObject = q.defer();
		needle.get("https://"+self.config.profileEnvt+"."+profileEndpointUrls[self.config.region]+"/auth/o2/tokeninfo?access_token="+access_token,
			function(err, response, body){
				if (err !== null)
					deferredObject.reject(err);
				else {
					console.log("profile data", body);
					deferredObject.resolve(body);
				}
			}
		);
		return deferredObject.promise;
	};

	self.getOrderDetails = function(orderReferenceId, addressConsentToken) {
		var params = getBaseParams("GetOrderReferenceDetails", self.config);
		params.AmazonOrderReferenceId = orderReferenceId;
		if (addressConsentToken)
			params.AddressConsentToken = addressConsentToken;

		return executeRequest(self.config, params);
	};
	return self;
};