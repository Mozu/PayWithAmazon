# amazonpay
### version 0.1.0

Mozu Pay By Amazon Application